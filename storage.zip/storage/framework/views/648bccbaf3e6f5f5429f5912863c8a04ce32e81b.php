<!doctype html>
<html lang="en">

<head>
    <title><?php echo e($page_title); ?> :: <?php echo e(env('APP_NAME')); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="icon" href="images/favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i,900,900i%7CMerriweather:300,300i,400,400i,700,700i,900,900i"
        rel="stylesheet">

    <!-- Bootstrap Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-4.4.1.min.css')); ?>">


    <!-- Sidebar Stylesheet -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.mCustomScrollbar.min.css')); ?>">

    <!-- Font Awesome Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">

    <!-- Custom Stylesheets -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" id="cpswitch" href="<?php echo e(asset('css/red.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">

    <!-- Owl Carousel Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.css')); ?>">

    <!-- Flex Slider Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('css/flexslider.css')); ?>" type="text/css" />

    <!--Date-Picker Stylesheet-->
    <link rel="stylesheet" href="<?php echo e(asset('css/datepicker.css')); ?>">

    <!-- Magnific Gallery -->
    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<?php /**PATH /Users/Jefkruz/Sites/airflourishweb/resources/views/includes/head.blade.php ENDPATH**/ ?>