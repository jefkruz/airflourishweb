<?php $__env->startSection('content'); ?>

    <!--============= PAGE-COVER =============-->
    <section class="page-cover" id="cover-blog-details">
        <div class="container">
            <div class="row">
                <div class="col-sm">
                    <h1 class="page-title"><?php echo e($page_title); ?></h1>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><?php echo e($page_title); ?>r</li>
                    </ul>
                </div><!-- end columns -->
            </div><!-- end row -->
        </div><!-- end container -->
    </section><!-- end page-cover -->

    <!--==== INNERPAGE-WRAPPER =====-->
    <section class="innerpage-wrapper">

        <div id="blog-listings" class="innerpage-section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-9 col-xl-9 content-side">
                        <div class="space-right">

                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php  $post->slug = 'news/'.$post->slug;?>
                            <div class="main-block blog-post blog-list">
                                <div class="main-img blog-post-img">
                                    <a href="<?php echo e($post->slug); ?>">
                                        <img src="<?php echo e(asset('storage/'. $post->image)); ?>" class="img-fluid" alt="<?php echo e($post->title); ?>" />
                                    </a>
                                    <div class="main-mask blog-post-info">
                                        <ul class="list-inline list-unstyled blog-post-info">
                                            <li class="list-inline-item"><span><i class="fa fa-calendar"></i></span><?php echo e($post->created_at->format('d M Y')); ?></li>
                                            <li class="list-inline-item"><span><i class="fa fa-user"></i></span>By: <a href="<?php echo e($post->slug); ?>">Administrator</a></li>
                                        </ul>
                                    </div>
                                </div><!-- end blog-post-img -->

                                <div class="blog-post-detail">
                                    <h2 class="blog-post-title"><a href="<?php echo e($post->slug); ?>"><?php echo e(ucwords($post->title)); ?></a></h2>
                                    <p><?php echo html_entity_decode(Str::limit($post->body, 200)); ?></p>
                                    <a href="<?php echo e($post->slug); ?>" class="btn btn-orange">View More</a>
                                </div><!-- end blog-post-detail -->
                            </div><!-- end blog-post -->

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div><!-- end space-right -->
                    </div><!-- end columns -->

                    <div class="col-12 col-md-12 col-lg-3 col-xl-3 side-bar blog-sidebar right-side-bar">

                        <div class="row">

                            <div class="col-12 col-md-6 col-lg-12">
                                <div class="side-bar-block contact">
                                    <h2 class="side-bar-heading">Contact Us</h2>
                                    <div class="c-list">
                                        <div class="icon"><span><i class="fa fa-envelope"></i></span></div>
                                        <div class="text"><p > <a href="mailto:info.sales@airflourish.com" class="text-danger">info.sales@airflourish.com</a></p></div>
                                    </div><!-- end c-list -->

                                    <div class="c-list">
                                        <div class="icon"><span><i class="fa fa-phone"></i></span></div>
                                        <div class="text"><p> <a href="tel:+234 913 4779 928" class="text-danger">+234 913 4779 928</a></p></div>
                                    </div><!-- end c-list -->

                                    <div class="c-list">
                                        <div class="icon"><span><i class="fa fa-map-marker"></i></span></div>
                                        <div class="text"><p>Address: 21/23 Billings Way Oregun.</p></div>
                                    </div><!-- end c-list -->
                                </div><!-- end side-bar-block -->
                            </div>

                        </div><!-- end row -->


                    </div><!-- end columns -->

                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end blog-listings -->
    </section><!-- end innerpage-wrapper -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Jefkruz/Sites/airflourishweb/resources/views/pages/news.blade.php ENDPATH**/ ?>