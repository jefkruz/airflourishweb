
<!-- Page Scripts Starts -->
<script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-rtl-4.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.flexslider.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom-navigation.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom-flex.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom-owl.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom-date-picker.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom-video.js')); ?>"></script>

<!-- Page Scripts Ends -->

<?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH /Users/Jefkruz/Sites/airflourishweb/resources/views/includes/scripts.blade.php ENDPATH**/ ?>